import React, { useEffect, useState, useContext, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import AuthContext from '../context/AuthContext';
import './BookReader.css';

const BookReader = () => {
  const { bookId } = useParams();
  const { user } = useContext(AuthContext);
  const [content, setContent] = useState('');
  const [currentPosition, setCurrentPosition] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const CHUNK_SIZE = 2000; // Number of characters per chunk

  const fetchProgress = useCallback(async () => {
    if (!user) {
      setError('User is not logged in.');
      return 0;
    }

    try {
      const response = await fetch(
        `/api/books/${bookId}/progress?userId=${user.id}`
      );
      if (!response.ok) {
        throw new Error('Failed to fetch reading progress');
      }
      const data = await response.json();
      return data.lastReadPosition || 0;
    } catch (err) {
      console.error('Error fetching progress:', err.message);
      setError('Failed to fetch progress.');
      return 0;
    }
  }, [bookId, user]);

  const fetchContent = useCallback(async (position) => {
    try {
      const response = await fetch(
        `/api/books/${bookId}/content?start=${position}&length=${CHUNK_SIZE}`
      );
      if (!response.ok) {
        throw new Error('Failed to fetch book content');
      }
      const data = await response.json();
      setContent(data.content);
      setCurrentPosition(position);
    } catch (err) {
      console.error('Error fetching content:', err.message);
      setError('Failed to fetch book content.');
    } finally {
      setLoading(false);
    }
  }, [bookId]);

  useEffect(() => {
    const initializeReader = async () => {
      setLoading(true);
      const lastReadPosition = await fetchProgress();
      await fetchContent(lastReadPosition);
    };

    initializeReader();
  }, [fetchContent, fetchProgress]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  // Split content at the nearest space to avoid breaking words
  const midpoint = Math.floor(content.length / 2);
  const splitPoint = content.lastIndexOf(' ', midpoint);
  const leftPage = content.slice(0, splitPoint);
  const rightPage = content.slice(splitPoint + 1); // Skip the space

  return (
    <div className="book-reader">
      <div className="page left-page">{leftPage}</div>
      <div className="page right-page">{rightPage}</div>
    </div>
  );
};

export default BookReader;
