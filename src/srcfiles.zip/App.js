// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';  // Import App.css to apply its styles
import Home from './components/Home';
import Header from './components/Header';
import BookReader from './components/BookReader';
import BookProduct from './components/BookProduct';
import Login from './components/Login';
import SignupForm from './components/SignupForm';
import { AuthProvider } from './context/AuthContext';
import Library from './components/Library';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Header /> {/* Header is now displayed on all pages */}
        
          <Routes> 
          
            <Route path="/" element={<Home />} />
            <Route path="/reader/:bookId" element={<ProtectedRoute><BookReader /></ProtectedRoute>} />
            {/* Route for individual book product pages */}
            <Route path="/books/:bookId" element={<BookProduct />} />
            <Route path="/login" element={<Login />} /> {/* Login route */}
            <Route path="/signup" element={<SignupForm />} /> {/* SignUp route */}
            <Route path="/library" element={<ProtectedRoute><Library /></ProtectedRoute>} />
          </Routes>
        
      </Router>
    </AuthProvider>
  );
}

export default App;
